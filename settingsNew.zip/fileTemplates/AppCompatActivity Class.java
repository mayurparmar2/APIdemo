#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import androidx.appcompat.app.AppCompatActivity;
public class ${NAME} extends AppCompatActivity {
    private final String TAG = "${NAME}";
    private final Context mContext = this;
   //  ${NAME}Binding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_${NAME});
            //For ViewBinding
       
            // binding = ${NAME}Binding.inflate(getLayoutInflater());
            // setContentView(binding.getRoot());

            //For DataBinding
            // binding= DataBindingUtil.setContentView(this,R.layout.activity_${NAME});
    }
}