#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.demo.example.R

class ${NAME}(private val context: Context,private val m${Model}: List<${Model}>,listener:On${Model}ItemClick) : RecyclerView.Adapter<${NAME}.ViewHolder>() {
    val on${Model}ItemClick: On${Model}ItemClick = listener
    interface On${Model}ItemClick {
        fun onClick()
    }
    private var currentFilterOption: FilterOption? = null
    private var m${Model}Filtered: List<${Model}> = m${Model}.toList()
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.${NAME}_item, viewGroup, false)
        return ViewHolder(view)
    }
    override fun getItemCount() = m${Model}Filtered.size
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        viewHolder.bind(m${Model}Filtered[position])
    }
  inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        fun bind(m${Model}: ${Model}) {
            itemView.setOnClickListener {
                on${Model}ItemClick.onClick()
            }
        
        }
    }
    
    fun applyFilter(filterOption: FilterOption) {
      currentFilterOption = filterOption
        when (filterOption) {
            FilterOption.SHORTBY_NAME -> {
                m${Model}Filtered = m${Model}.sortedBy { it.departureTime }
            }
        }
        notifyDataSetChanged()
    }
   enum class FilterOption {
        SHORTBY_NAME
    }
}