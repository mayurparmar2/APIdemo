#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
#parse("File Header.java")

@Entity(tableName = "m${NAME}")
public class ${NAME}(
        @ColumnInfo(name = "mTitle")val mTitle :String
    ){
    @PrimaryKey(autoGenerate = true) var id = 0
}