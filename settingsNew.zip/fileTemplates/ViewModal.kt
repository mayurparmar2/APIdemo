#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
#parse("File Header.java")
class ${NAME}(application: Application):AndroidViewModel(application) {

    private var m${Model}repository:${Model}Repository
    val all${Model} : LiveData<List<${Model}>>
    init {
        val dao = ${Model}Database.getDatabase(application).get${Model}Dao()
        m${Model}repository = ${Model}Repository(dao)
        all${Model} = m${Model}repository.all${Model}
    }
    fun add${Model}(m${Model}: ${Model}){
        viewModelScope.launch(Dispatchers.IO) {
            m${Model}repository.insert${Model}(m${Model})
        }
    }
    fun update${Model}(m${Model}: ${Model}){
        viewModelScope.launch(Dispatchers.IO) {
            m${Model}repository.update${Model}(m${Model})
        }
    }
    fun delete${Model}(m${Model}: ${Model}){
        viewModelScope.launch(Dispatchers.IO) {
            m${Model}repository.delete${Model}(m${Model})
        }
    }
}