#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
#parse("File Header.java")
object ${NAME} {
    private const val BASE_URL = "${BASE_URL}"

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val api${Service}: Api${Service} = retrofit.create(Api${Service}::class.java)
}
